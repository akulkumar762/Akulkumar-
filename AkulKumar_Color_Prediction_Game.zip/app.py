from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

colors = ["Red", "Green", "Blue"]
bet_data = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/place_bet', methods=['POST'])
def place_bet():
    data = request.json
    username = data.get("username")
    bet_amount = data.get("bet_amount")
    bet_color = data.get("bet_color")

    if bet_amount < 1 or bet_amount > 100000:
        return jsonify({"error": "Bet amount must be between 1 and 100000"}), 400

    bet_data[username] = {"bet_amount": bet_amount, "bet_color": bet_color}
    return jsonify({"message": "Bet placed successfully!"})

@app.route('/result', methods=['GET'])
def result():
    if not bet_data:
        return jsonify({"error": "No bets placed yet"}), 400

    winning_color = random.choice(colors)
    results = {}

    for user, data in bet_data.items():
        if data["bet_color"] == winning_color:
            results[user] = {"status": "Win", "amount_won": data["bet_amount"] * 2}
        else:
            results[user] = {"status": "Lose", "amount_won": 0}

    bet_data.clear()
    return jsonify({"winning_color": winning_color, "results": results})

if __name__ == '__main__':
    app.run(debug=True)
